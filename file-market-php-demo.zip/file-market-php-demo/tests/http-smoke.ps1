param(
    [string]$BaseUrl = 'http://127.0.0.1:8080'
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Net.Http
$script:passed = 0

function Assert-That([bool]$Condition, [string]$Description) {
    if (-not $Condition) { throw "FAIL: $Description" }
    $script:passed++
    Write-Host "PASS $Description"
}

function New-DemoClient {
    $handler = [System.Net.Http.HttpClientHandler]::new()
    $handler.CookieContainer = [System.Net.CookieContainer]::new()
    $handler.UseCookies = $true
    $client = [System.Net.Http.HttpClient]::new($handler)
    $client.BaseAddress = [Uri]($BaseUrl.TrimEnd('/') + '/')
    $client.Timeout = [TimeSpan]::FromSeconds(15)
    return [pscustomobject]@{ Client = $client; Handler = $handler }
}

function Send-DemoRequest($Client, [string]$Method, [string]$Path, [string]$Body = '', [string]$Token = '', [string]$ContentType = 'application/json') {
    $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::new($Method), $Path)
    try {
        if ($Method -ne 'GET') {
            $request.Content = [System.Net.Http.StringContent]::new($Body, [System.Text.Encoding]::UTF8, $ContentType)
        }
        if ($Token -ne '') { $null = $request.Headers.TryAddWithoutValidation('X-CSRF-Token', $Token) }
        $response = $Client.SendAsync($request).GetAwaiter().GetResult()
        try {
            $raw = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
            $json = $null
            if ($response.Content.Headers.ContentType.MediaType -eq 'application/json') { $json = $raw | ConvertFrom-Json }
            return [pscustomobject]@{ Status = [int]$response.StatusCode; Body = $raw; Json = $json; Headers = $response.Headers.ToString() + $response.Content.Headers.ToString() }
        } finally { $response.Dispose() }
    } finally { $request.Dispose() }
}

function Send-DemoApi($Client, $Payload, [string]$Token = '') {
    return Send-DemoRequest $Client 'POST' 'api.php' ($Payload | ConvertTo-Json -Compress -Depth 8) $Token
}

function Product-Ids([string]$Html) {
    return (@([regex]::Matches($Html, '<article class="product-card" data-product="(\d+)">') | ForEach-Object { $_.Groups[1].Value }) -join ',')
}

$first = New-DemoClient
$second = New-DemoClient
try {
    $homePage = Send-DemoRequest $first.Client 'GET' 'index.php'
    Assert-That ($homePage.Status -eq 200) 'Home returns HTTP 200'
    $csrfMatch = [regex]::Match($homePage.Body, '<meta name="csrf-token" content="([a-f0-9]{64})">')
    Assert-That $csrfMatch.Success 'Home exposes a 64-character session CSRF token'
    $token = $csrfMatch.Groups[1].Value
    $cookie = $first.Handler.CookieContainer.GetCookies([Uri]$BaseUrl)['FILEDEMOSESSID']
    Assert-That ($null -ne $cookie -and $cookie.HttpOnly) 'Real session cookie is retained and HttpOnly'
    Assert-That ($homePage.Headers -match 'SameSite=Lax') 'Session cookie sets SameSite=Lax'
    Assert-That ($homePage.Headers -match "Content-Security-Policy:.*script-src 'self'") 'CSP limits scripts to local assets'

    $secondHome = Send-DemoRequest $second.Client 'GET' 'index.php'
    $secondToken = [regex]::Match($secondHome.Body, '<meta name="csrf-token" content="([a-f0-9]{64})">').Groups[1].Value
    $secondCookie = $second.Handler.CookieContainer.GetCookies([Uri]$BaseUrl)['FILEDEMOSESSID']
    Assert-That ($secondToken -ne $token -and $secondCookie.Value -ne $cookie.Value) 'Independent clients receive separate sessions and tokens'
    $crossSession = Send-DemoApi $second.Client @{ action = 'add'; id = 32 } $token
    Assert-That ($crossSession.Status -eq 403 -and $crossSession.Json.ok -eq $false) 'CSRF token from another cookie session is rejected'

    $method = Send-DemoRequest $first.Client 'GET' 'api.php'
    Assert-That ($method.Status -eq 405 -and $method.Headers -match 'Allow: POST') 'API rejects GET and announces POST'
    $missingCsrf = Send-DemoApi $first.Client @{ action = 'add'; id = 32 }
    Assert-That ($missingCsrf.Status -eq 403 -and $missingCsrf.Json.ok -eq $false) 'Missing CSRF token is rejected'
    $unknown = Send-DemoApi $first.Client @{ action = 'add'; id = 999999999 } $token
    Assert-That ($unknown.Status -eq 404) 'Unknown product is rejected'
    foreach ($badQuantity in @(0, 100, 1.5, '2', $null)) {
        $invalid = Send-DemoApi $first.Client @{ action = 'add'; id = 32; quantity = $badQuantity } $token
        Assert-That ($invalid.Status -eq 422) "Invalid quantity rejected: $($badQuantity | ConvertTo-Json -Compress)"
    }
    $badId = Send-DemoApi $first.Client @{ action = 'add'; id = '32' } $token
    Assert-That ($badId.Status -eq 422) 'Numeric string product id is rejected'
    $badJson = Send-DemoRequest $first.Client 'POST' 'api.php' '{broken' $token
    Assert-That ($badJson.Status -eq 400) 'Malformed JSON is rejected'
    $arrayJson = Send-DemoRequest $first.Client 'POST' 'api.php' '[]' $token
    Assert-That ($arrayJson.Status -eq 400) 'JSON array body is rejected'
    $badType = Send-DemoRequest $first.Client 'POST' 'api.php' 'action=add&id=32' $token 'text/plain'
    Assert-That ($badType.Status -eq 415) 'Unsupported content type is rejected'
    $tooLarge = Send-DemoRequest $first.Client 'POST' 'api.php' ('x' * 9000) $token
    Assert-That ($tooLarge.Status -eq 413) 'Oversized request body is rejected'
    $tamperedTotal = Send-DemoApi $first.Client @{ action = 'add'; id = 32; quantity = 2; total = 1; price = 1 } $token
    Assert-That ($tamperedTotal.Status -eq 400) 'Client-supplied prices and totals are rejected'
    $emptyOrder = Send-DemoApi $first.Client @{ action = 'demo_order' } $token
    Assert-That ($emptyOrder.Status -eq 422) 'Empty cart cannot create a demo order'

    $catalog = Get-Content -LiteralPath (Join-Path $PSScriptRoot '..\app\catalog.json') -Raw | ConvertFrom-Json
    $productOne = $catalog | Where-Object id -eq 32
    $productTwo = $catalog | Where-Object id -eq 1086
    Assert-That ($null -ne $productOne -and $null -ne $productTwo) 'Expected catalogue products are available for checks'
    $add = Send-DemoApi $first.Client @{ action = 'add'; id = 32; quantity = 2 } $token
    Assert-That ($add.Status -eq 200 -and $add.Json.ok -and $add.Json.cart.count -eq 2) 'Add creates two cart units'
    Assert-That ($add.Json.cart.total -eq 2 * $productOne.price -and $add.Json.cart.items[0].line_total -eq 2 * $productOne.price -and $add.Json.cart.shipping -eq 0) 'Server calculates exact integer catalogue totals and zero shipping'
    $increment = Send-DemoApi $first.Client @{ action = 'add'; id = 32 } $token
    Assert-That ($increment.Json.cart.count -eq 3 -and $increment.Json.cart.items[0].quantity -eq 3) 'Repeated add increments existing quantity'
    $addSecond = Send-DemoApi $first.Client @{ action = 'add'; id = 1086; quantity = 2 } $token
    Assert-That ($addSecond.Json.cart.count -eq 5 -and $addSecond.Json.cart.total -eq (3 * $productOne.price + 2 * $productTwo.price)) 'Multiple product totals are computed on the server'
    $quantity = Send-DemoApi $first.Client @{ action = 'quantity'; id = 32; quantity = 4 } $token
    Assert-That ($quantity.Json.cart.count -eq 6 -and $quantity.Json.cart.total -eq (4 * $productOne.price + 2 * $productTwo.price)) 'Quantity update replaces quantity and recomputes total'
    $maximum = Send-DemoApi $first.Client @{ action = 'quantity'; id = 1086; quantity = 99 } $token
    Assert-That ($maximum.Status -eq 200 -and $maximum.Json.cart.count -eq 103) 'Quantity 99 is accepted'
    $overflow = Send-DemoApi $first.Client @{ action = 'add'; id = 1086 } $token
    Assert-That ($overflow.Status -eq 422) 'Add cannot overflow quantity 99'
    $null = Send-DemoApi $first.Client @{ action = 'quantity'; id = 1086; quantity = 2 } $token

    $isolated = Send-DemoRequest $second.Client 'GET' 'index.php?p=cart'
    Assert-That ($isolated.Body.Contains('Sepetiniz henüz boş')) 'Other session cannot see the first cart'
    $favorite = Send-DemoApi $first.Client @{ action = 'favorite'; id = 32 } $token
    Assert-That ($favorite.Json.favorites -contains 32) 'Favorite toggle adds the product'
    $favoritePage = Send-DemoRequest $first.Client 'GET' 'index.php?p=favorites'
    Assert-That ((Product-Ids $favoritePage.Body) -eq '32') 'Favorites page renders session selection'
    $unfavorite = Send-DemoApi $first.Client @{ action = 'favorite'; id = 32 } $token
    Assert-That ($unfavorite.Json.favorites -notcontains 32) 'Favorite toggle removes the product'
    $remove = Send-DemoApi $first.Client @{ action = 'remove'; id = 32 } $token
    Assert-That ($remove.Json.cart.count -eq 2 -and $remove.Json.cart.total -eq 2 * $productTwo.price) 'Remove deletes the row and recomputes total'
    $clear = Send-DemoApi $first.Client @{ action = 'clear' } $token
    Assert-That ($clear.Json.cart.count -eq 0 -and $clear.Json.cart.total -eq 0 -and @($clear.Json.cart.items).Count -eq 0) 'Clear empties all cart rows'

    $null = Send-DemoApi $first.Client @{ action = 'add'; id = 32; quantity = 2 } $token
    $null = Send-DemoApi $first.Client @{ action = 'add'; id = 1086 } $token
    $expectedTotal = 2 * $productOne.price + $productTwo.price
    $privateField = Send-DemoApi $first.Client @{ action = 'demo_order'; address = 'must-not-be-collected' } $token
    Assert-That ($privateField.Status -eq 400) 'Demo order rejects additional personal-information fields'
    $order = Send-DemoApi $first.Client @{ action = 'demo_order' } $token
    Assert-That ($order.Status -eq 200 -and $order.Json.redirect -eq 'index.php?p=order' -and $order.Json.cart.count -eq 0 -and $order.Json.cart.total -eq 0) 'Demo order returns summary redirect and clears the cart'
    $receipt = Send-DemoRequest $first.Client 'GET' $order.Json.redirect
    $expectedMoney = ($expectedTotal / 100).ToString('N2', [Globalization.CultureInfo]::GetCultureInfo('tr-TR')) + ' TL'
    Assert-That ($receipt.Status -eq 200 -and $receipt.Body -match 'DEMO-\d{8}-[A-F0-9]{8}' -and $receipt.Body.Contains($expectedMoney) -and $receipt.Body.Contains('2 × ' + $productOne.name) -and $receipt.Body.Contains('1 × ' + $productTwo.name)) 'Order page persists the correct product quantities and server-calculated total'
    $cartAfterOrder = Send-DemoRequest $first.Client 'GET' 'index.php?p=cart'
    Assert-That ($cartAfterOrder.Body.Contains('Sepetiniz henüz boş')) 'Cart page remains empty after demo order'
    $otherReceipt = Send-DemoRequest $second.Client 'GET' 'index.php?p=order'
    Assert-That ($otherReceipt.Body.Contains('Henüz demo siparişi yok')) 'Order summary is isolated from other sessions'

    $turkish = Send-DemoRequest $first.Client 'GET' ('index.php?p=category&q=' + [Uri]::EscapeDataString('AYÇİÇEK'))
    $ascii = Send-DemoRequest $first.Client 'GET' 'index.php?p=category&q=aycicek'
    Assert-That ($turkish.Status -eq 200 -and (Product-Ids $turkish.Body).Split(',') -contains '32') 'Turkish uppercase search finds AYÇİÇEK product'
    Assert-That ((Product-Ids $turkish.Body) -eq (Product-Ids $ascii.Body)) 'Turkish and ASCII search normalization returns matching product ids'
    $tea = Send-DemoRequest $first.Client 'GET' ('index.php?p=category&q=' + [Uri]::EscapeDataString('ÇAY'))
    Assert-That ((Product-Ids $tea.Body).Split(',') -contains '1878') 'Turkish cedilla search finds Çaykur product'
    $searchInput = '"><img src=x onerror=alert(1)> & ''Çay'''
    $escaped = Send-DemoRequest $first.Client 'GET' ('index.php?p=category&q=' + [Uri]::EscapeDataString($searchInput))
    Assert-That ($escaped.Status -eq 200 -and $escaped.Body.Contains('&quot;&gt;&lt;img src=x onerror=alert(1)&gt; &amp; &#039;Çay&#039;') -and -not $escaped.Body.Contains('<img src=x onerror=alert(1)>')) 'Search payload is HTML-escaped in input and visible results'

    Write-Host "All $script:passed HTTP integration checks passed against $BaseUrl."
} finally {
    $first.Client.Dispose()
    $second.Client.Dispose()
}
