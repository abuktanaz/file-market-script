<?php
declare(strict_types=1);
date_default_timezone_set('Europe/Istanbul');

// Shared initialization. This file must not print anything before a response.
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

header('Content-Type: text/html; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
header('Cache-Control: no-store, max-age=0');
header("Content-Security-Policy: default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'");

if (session_status() === PHP_SESSION_NONE) {
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443');
    session_name('FILEDEMOSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    if (!session_start()) {
        throw new RuntimeException('Oturum başlatılamadı.');
    }
}

if (!isset($_SESSION['_initialized'])) {
    session_regenerate_id(true);
    $_SESSION['_initialized'] = true;
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function money(int $cents): string
{
    return number_format($cents / 100, 2, ',', '.') . ' TL';
}

/** @return list<array<string, mixed>> */
function catalog(): array
{
    static $products = null;
    if ($products !== null) {
        return $products;
    }

    $json = file_get_contents(__DIR__ . '/catalog.json');
    if ($json === false) {
        throw new RuntimeException('Ürün kataloğu okunamadı.');
    }
    try {
        $data = json_decode($json, true, 64, JSON_THROW_ON_ERROR);
    } catch (JsonException $exception) {
        throw new RuntimeException('Ürün kataloğu geçerli JSON içermiyor.', 0, $exception);
    }
    if (!is_array($data) || !array_is_list($data)) {
        throw new RuntimeException('Ürün kataloğu bir JSON listesi olmalıdır.');
    }

    $products = [];
    $seen = [];
    foreach ($data as $row) {
        if (!is_array($row)
            || !isset($row['id'], $row['name'], $row['category'], $row['image'], $row['price'], $row['description'])
            || !is_int($row['id']) || $row['id'] < 1 || isset($seen[$row['id']])
            || !is_string($row['name']) || trim($row['name']) === '' || strlen($row['name']) > 300
            || !is_string($row['category']) || !preg_match('/\A[a-z0-9]+(?:-[a-z0-9]+)*\z/D', $row['category'])
            || !is_string($row['image']) || !preg_match('~\Aassets/images/[a-zA-Z0-9][a-zA-Z0-9._/-]*\.(?:svg|webp|png|jpe?g|avif|gif)\z~D', $row['image'])
            || in_array('..', explode('/', $row['image']), true)
            || !is_int($row['price']) || $row['price'] < 0 || $row['price'] > 100000000
            || !is_string($row['description']) || strlen($row['description']) > 10000
            || (isset($row['old_price']) && (!is_int($row['old_price']) || $row['old_price'] < 0 || $row['old_price'] > 100000000))
            || (isset($row['featured']) && !is_bool($row['featured']))) {
            throw new RuntimeException('Ürün kataloğunda geçersiz veya tekrarlanan bir kayıt var.');
        }
        $seen[$row['id']] = true;
        $row['name'] = trim($row['name']);
        $row['old_price'] = $row['old_price'] ?? 0;
        $row['featured'] = $row['featured'] ?? false;
        $products[] = $row;
    }
    return $products;
}

/** @return array<string, mixed>|null */
function product(int $id): ?array
{
    static $indexed = null;
    if ($indexed === null) {
        $indexed = [];
        foreach (catalog() as $entry) {
            $indexed[$entry['id']] = $entry;
        }
    }
    return $indexed[$id] ?? null;
}

/** @return list<array{product: array<string, mixed>, quantity: int, line_total: int}> */
function cart_items(): array
{
    $stored = $_SESSION['cart'] ?? [];
    $normalized = [];
    $rows = [];
    if (!is_array($stored)) {
        $stored = [];
    }
    foreach ($stored as $id => $quantity) {
        if (count($rows) >= 50) {
            break;
        }
        if ((!is_int($id) && (!is_string($id) || !ctype_digit($id)))
            || !is_int($quantity) || $quantity < 1 || $quantity > 99) {
            continue;
        }
        $entry = product((int) $id);
        if ($entry === null) {
            continue;
        }
        $normalized[$entry['id']] = $quantity;
        $rows[] = [
            'product' => $entry,
            'quantity' => $quantity,
            'line_total' => $entry['price'] * $quantity,
        ];
    }
    $_SESSION['cart'] = $normalized;
    return $rows;
}

/** @return array{count: int, subtotal: int, shipping: int, total: int, items: array} */
function cart_summary(): array
{
    $items = cart_items();
    $subtotal = 0;
    $count = 0;
    foreach ($items as $row) {
        $subtotal += $row['line_total'];
        $count += $row['quantity'];
    }
    return [
        'count' => $count,
        'subtotal' => $subtotal,
        'shipping' => 0,
        'total' => $subtotal,
        'items' => $items,
    ];
}

function csrf_token(): string
{
    if (!isset($_SESSION['csrf']) || !is_string($_SESSION['csrf'])
        || !preg_match('/\A[a-f0-9]{64}\z/D', $_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

/** @return list<int> */
function favorites(): array
{
    $stored = $_SESSION['favorites'] ?? [];
    $valid = [];
    if (is_array($stored)) {
        foreach ($stored as $id) {
            if (is_int($id) && $id > 0 && product($id) !== null) {
                $valid[$id] = $id;
            }
        }
    }
    $_SESSION['favorites'] = array_values($valid);
    return $_SESSION['favorites'];
}
