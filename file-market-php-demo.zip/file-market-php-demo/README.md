# FİLE — bağımsız PHP mağaza demosu

Türkçe arayüz, ürün kataloğu, kategori ve arama ekranları, favoriler, sepet ve örnek sipariş akışı içeren bağımsız bir tasarım demosudur. FİLE veya başka bir marka ile resmî bağlantısı yoktur. Görseller ve ürün bilgileri tanıtım amaçlıdır; fiyatlar ve stoklar gerçek satış teklifi oluşturmaz.

**Gerçek sipariş, ödeme, kart girişi, üyelik veya teslimat yoktur.** Demo sipariş düğmesi yalnızca mevcut PHP oturumunda bir örnek kayıt oluşturur. Adres, telefon, kimlik, şifre veya ödeme bilgisi toplanmaz. Veri tabanı, yönetim paneli ve MySQL bağlantısı bulunmaz.

## Gereksinimler

- PHP 8.2 veya üzeri; standart JSON ve Session desteği.
- Modern bir tarayıcı.
- Yerel kullanım için PHP'nin geliştirme sunucusu; yayımlama için PHP destekli web sunucusu ve HTTPS.

## Yerel çalıştırma

Proje klasöründen PowerShell ile:

```powershell
.\start.ps1
```

Ardından tarayıcıda `http://127.0.0.1:8080` adresini açın. Başlatıcı önce proje ile aynı üst klasördeki `.tools\php\php.exe` dosyasını, sonra PATH üzerindeki `php` komutunu arar. Farklı bir port için `.\start.ps1 -Port 8090` kullanabilirsiniz. Sunucuyu `Ctrl+C` ile durdurun.

PHP kuruluysa aynı işlem doğrudan şöyle yapılır:

```powershell
php -S 127.0.0.1:8080 -t public
```

PHP geliştirme sunucusu yerel önizleme içindir. İnternete açık üretim sunucusu olarak kullanılmamalıdır.

## Klasör yapısı ve barındırma

```text
app/
  bootstrap.php       Oturum, güvenlik başlıkları ve mağaza yardımcıları
  catalog.json        Ürün kataloğu
  categories.json     Kategori adları ve görselleri
  icons.php           Yerel SVG simgeleri
public/
  index.php           Mağaza arayüzü
  api.php             Sepet, favoriler ve demo sipariş uç noktası
  assets/             Yerel stil, JavaScript ve görseller
  .htaccess           Apache dizin listesi ve gizli dosya koruması
start.ps1             Yerel başlatıcı
preview/              Doğrulanan masaüstü ve mobil ekran görüntüleri
tests/                HTTP işlev kontrolleri
```

Web sunucusunun **document root / belge kökü `public/` olmalıdır**. Projenin üst klasörünü veya `app/` dizinini web üzerinden sunmayın. Apache için `.htaccess` desteğini etkinleştirin; Nginx gibi diğer sunucularda gizli dosyaları engelleyin ve dizin listelemeyi kapatın. Oturumların çalışması için PHP'nin oturum kayıt dizininin sunucu tarafından yazılabilir olması gerekir. Üretimde HTTPS kullanın; uygulama doğrudan HTTPS bağlantısında oturum çerezine `Secure` niteliği ekler.

## Ürünleri değiştirme

`app/catalog.json` bir JSON dizisidir. Örnek kayıt:

```json
{
  "id": 101,
  "name": "Örnek ürün",
  "category": "gida",
  "image": "assets/images/ornek-urun.svg",
  "price": 24900,
  "old_price": 29900,
  "featured": true,
  "description": "Ürünün kısa açıklaması."
}
```

Her `id` benzersiz, pozitif tam sayı olmalıdır. Fiyatlar **kuruş** cinsinden tam sayıdır: `24900` değeri `249,00 TL` olarak gösterilir. İndirim öncesi fiyat yoksa `old_price` alanını `0` yapın. Kategori, küçük harfli Latin harfleri/rakamlar ve tirelerden oluşan bir anahtar olmalıdır; arayüzde tanımlı kategori anahtarlarını kullanın. Görselleri `public/assets/images/` içine koyun; `image` alanında yukarıdaki gibi yerel yol kullanın. Katalog dosyasındaki içerik ve görsel haklarından siteyi yayımlayan kişi sorumludur.

## Demo davranışı ve güvenlik

- Sepet ve favoriler sunucudaki PHP oturumunda tutulur; farklı tarayıcılarla paylaşılmaz. Oturum sona erdiğinde kalıcı kayıt güvencesi yoktur.
- Sepette en fazla 50 farklı ürün ve her üründen 99 adet bulunabilir. Demo kargo bedeli daima `0`'dır.
- `public/api.php` yalnızca JSON biçiminde `POST` kabul eder. Sayfanın ürettiği oturum CSRF belirteci `X-CSRF-Token` başlığıyla gönderilir.
- İzin verilen işlemler `add`, `quantity`, `remove`, `clear`, `favorite` ve `demo_order`'dır. Desteklenmeyen alanlar, hatalı adetler ve 8 KB üzeri istekler reddedilir.
- `demo_order` yalnızca `{"action":"demo_order"}` kabul eder; mevcut sepeti oturumda bir demo siparişe dönüştürür ve sepeti boşaltır. Haricî servise veri gönderilmez.
- Çerezler `HttpOnly` ve `SameSite=Lax` kullanır. Güvenlik başlıkları, yerel betik/stil politikası ve çıktı kaçışlaması uygulanır.

Canlı satışa geçmek ayrı bir geliştirme kapsamıdır: gerçek ürün/stok kaynağı, hesap ve yetki yönetimi, kalıcı veri tabanı, sipariş yaşam döngüsü, mevzuata uygun metinler ve güvenilir bir ödeme sağlayıcısı ayrıca tasarlanmalıdır.

## İşlev kontrolü

Yerel sunucu çalışırken ikinci bir PowerShell penceresinde `.\tests\http-smoke.ps1` komutunu çalıştırabilirsiniz. Farklı bir port için `-BaseUrl http://127.0.0.1:8090` parametresini ekleyin. Kontroller iki bağımsız çerez oturumu oluşturur; CSRF, sepet/favoriler, sunucuda hesaplanan toplamlar, demo sipariş özeti, Türkçe arama ve HTML kaçışlamasını doğrular. Gerçek kişisel bilgi veya ödeme verisi kullanılmaz.
