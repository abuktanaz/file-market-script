'use strict';
(() => {
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => Array.from(root.querySelectorAll(s));
  const money = value => (value / 100).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' TL';
  const toast = $('#toast');
  let toastTimer;
  let pending = false;

  function notify(message, error = false, withCart = false) {
    clearTimeout(toastTimer);
    toast.replaceChildren(document.createTextNode(message));
    toast.classList.toggle('error', error);
    if (withCart) {
      const link = document.createElement('a');
      link.href = 'index.php?p=cart';
      link.textContent = 'Sepete git →';
      toast.append(link);
    }
    toast.hidden = false;
    toastTimer = setTimeout(() => { toast.hidden = true; }, error ? 6500 : 3500);
  }

  const categoryMenu = $('#category-menu');
  const categoryToggles = [$('#categories-toggle'), $('#menu-toggle')].filter(Boolean);
  function toggleCategories(open) {
    categoryMenu.hidden = !open;
    categoryToggles.forEach(button => button.setAttribute('aria-expanded', String(open)));
  }
  categoryToggles.forEach(button => button.addEventListener('click', () => toggleCategories(categoryMenu.hidden)));
  document.addEventListener('click', event => {
    if (!categoryMenu.hidden && !categoryMenu.contains(event.target) && !categoryToggles.some(button => button.contains(event.target))) toggleCategories(false);
  });

  const supportPanel = $('#support-panel');
  const supportToggle = $('#support-toggle');
  function toggleSupport(open) {
    supportPanel.hidden = !open;
    supportToggle.setAttribute('aria-expanded', String(open));
    if (open) $('#support-close').focus();
    else supportToggle.focus();
  }
  supportToggle.addEventListener('click', () => toggleSupport(supportPanel.hidden));
  $('#support-close').addEventListener('click', () => toggleSupport(false));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if (!categoryMenu.hidden) { toggleCategories(false); categoryToggles.find(b => b.offsetParent !== null)?.focus(); }
      if (!supportPanel.hidden) toggleSupport(false);
    }
  });
  $$('[data-scroll-top]').forEach(button => button.addEventListener('click', () => window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' })));

  $$('[data-slide]').forEach(button => button.addEventListener('click', () => {
    const index = Number(button.dataset.slide);
    $$('.hero-slide').forEach((slide, i) => { slide.hidden = i !== index; slide.classList.toggle('is-active', i === index); });
    $$('[data-slide]').forEach((dot, i) => { dot.classList.toggle('active', i === index); dot.setAttribute('aria-pressed', String(i === index)); });
  }));
  $('#sort')?.addEventListener('change', event => event.target.form.requestSubmit());

  const detailQuantity = $('#detail-quantity');
  const clampQuantity = value => Math.max(1, Math.min(99, Number.parseInt(value, 10) || 1));
  $$('[data-detail-quantity]').forEach(button => button.addEventListener('click', () => {
    detailQuantity.value = clampQuantity(clampQuantity(detailQuantity.value) + Number(button.dataset.detailQuantity));
  }));
  detailQuantity?.addEventListener('change', () => { detailQuantity.value = clampQuantity(detailQuantity.value); });

  function updateCart(cart) {
    $$('[data-cart-count]').forEach(element => { element.textContent = cart.count; });
    $$('[data-subtotal]').forEach(element => { element.textContent = money(cart.subtotal); });
    $$('[data-total]').forEach(element => { element.textContent = money(cart.total); });
    $$('[data-cart-row]').forEach(row => {
      const item = cart.items.find(item => item.product.id === Number(row.dataset.cartRow));
      if (!item) row.remove();
      else { $('[data-row-quantity]', row).textContent = item.quantity; $('[data-line-total]', row).textContent = money(item.line_total); }
    });
  }

  document.addEventListener('click', async event => {
    const button = event.target.closest('button[data-action]');
    if (!button || pending) return;
    const action = button.dataset.action;
    const payload = { action };
    if (button.dataset.id) payload.id = Number(button.dataset.id);
    if (action === 'add') payload.quantity = button.hasAttribute('data-detail-add') ? clampQuantity(detailQuantity.value) : 1;
    if (action === 'quantity') {
      const row = button.closest('[data-cart-row]');
      const quantity = Number($('[data-row-quantity]', row).textContent) + Number(button.dataset.delta);
      if (quantity < 1) payload.action = 'remove';
      else if (quantity > 99) { notify('Bir üründen en fazla 99 adet eklenebilir.', true); return; }
      else payload.quantity = quantity;
    }
    pending = true;
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000);
      let response;
      try {
        response = await fetch('api.php', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': $('meta[name="csrf-token"]').content },
          body: JSON.stringify(payload), signal: controller.signal
        });
      } finally { clearTimeout(timeout); }
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.message || 'İşlem tamamlanamadı. Lütfen tekrar deneyin.');
      updateCart(result.cart);
      if (action === 'favorite') {
        $$('[data-action="favorite"]').forEach(favoriteButton => {
          const active = result.favorites.includes(Number(favoriteButton.dataset.id));
          favoriteButton.classList.toggle('is-favorite', active);
          favoriteButton.setAttribute('aria-pressed', String(active));
        });
        if (document.body.dataset.page === 'favorites') { location.reload(); return; }
      }
      if (result.redirect) { location.href = result.redirect; return; }
      if (document.body.dataset.page === 'cart' && result.cart.count === 0) { location.reload(); return; }
      notify(result.message, false, action === 'add');
      if (action === 'add' && button.classList.contains('add-button')) {
        button.classList.add('added');
        const label = $('span', button);
        if (label) label.textContent = 'Sepete eklendi';
        setTimeout(() => { button.classList.remove('added'); if (label) label.textContent = 'Sepete Ekle'; }, 1700);
      }
    } catch (error) {
      notify(error.name === 'AbortError' ? 'Bağlantı zaman aşımına uğradı. Sepetinizi kontrol ederek tekrar deneyin.' : (error.message || 'Bağlantı kurulamadı. Lütfen tekrar deneyin.'), true);
    } finally {
      pending = false;
      button.disabled = false;
      button.removeAttribute('aria-busy');
    }
  });
})();
