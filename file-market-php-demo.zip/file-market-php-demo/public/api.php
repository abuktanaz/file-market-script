<?php
declare(strict_types=1);

/** @param array<string, mixed> $payload */
function json_response(array $payload, int $status = 200): never
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store, max-age=0');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

function api_error(string $message, int $status): never
{
    json_response(['ok' => false, 'message' => $message], $status);
}

try {
    require dirname(__DIR__) . '/app/bootstrap.php';

    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        header('Allow: POST');
        api_error('Bu işlem için POST isteği gereklidir.', 405);
    }
    $contentType = trim((string) ($_SERVER['CONTENT_TYPE'] ?? ''));
    if (!preg_match('/\Aapplication\/json(?:\s*;\s*charset\s*=\s*"?utf-8"?)?\s*\z/iD', $contentType)) {
        api_error('İstek application/json biçiminde olmalıdır.', 415);
    }

    $csrf = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($csrf) || !hash_equals(csrf_token(), $csrf)) {
        api_error('Oturum doğrulanamadı. Sayfayı yenileyip tekrar deneyin.', 403);
    }

    $maximumBytes = 8192;
    $length = $_SERVER['CONTENT_LENGTH'] ?? null;
    if ($length !== null && (!ctype_digit((string) $length) || (int) $length > $maximumBytes)) {
        api_error('İstek boyutu izin verilen sınırı aşıyor.', 413);
    }
    $raw = file_get_contents('php://input', false, null, 0, $maximumBytes + 1);
    if ($raw === false || strlen($raw) > $maximumBytes) {
        api_error('İstek boyutu izin verilen sınırı aşıyor.', 413);
    }
    try {
        $decoded = json_decode($raw, false, 16, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        api_error('Geçerli bir JSON isteği gönderin.', 400);
    }
    if (!$decoded instanceof stdClass) {
        api_error('İstek bir JSON nesnesi olmalıdır.', 400);
    }
    $input = get_object_vars($decoded);
    $action = $input['action'] ?? null;
    $allowed = [
        'add' => ['action', 'id', 'quantity'],
        'quantity' => ['action', 'id', 'quantity'],
        'remove' => ['action', 'id'],
        'clear' => ['action'],
        'favorite' => ['action', 'id'],
        'demo_order' => ['action'],
    ];
    if (!is_string($action) || !isset($allowed[$action])) {
        api_error('Bilinmeyen işlem.', 400);
    }
    if (array_diff(array_keys($input), $allowed[$action]) !== []) {
        api_error('İstek desteklenmeyen alanlar içeriyor. Kişisel veya ödeme bilgisi göndermeyin.', 400);
    }

    // Normalize session data before any mutation.
    cart_items();
    favorites();

    $id = null;
    if (in_array($action, ['add', 'quantity', 'remove', 'favorite'], true)) {
        $id = $input['id'] ?? null;
        if (!is_int($id) || $id < 1) {
            api_error('Geçerli bir ürün numarası gereklidir.', 422);
        }
        if (product($id) === null) {
            api_error('Ürün bulunamadı.', 404);
        }
    }

    $message = '';
    $extra = [];
    switch ($action) {
        case 'add':
        case 'quantity':
            $quantity = array_key_exists('quantity', $input) ? $input['quantity'] : ($action === 'add' ? 1 : null);
            if (!is_int($quantity) || $quantity < 1 || $quantity > 99) {
                api_error('Ürün adedi 1 ile 99 arasında bir tam sayı olmalıdır.', 422);
            }
            if (!isset($_SESSION['cart'][$id]) && count($_SESSION['cart']) >= 50) {
                api_error('Sepete en fazla 50 farklı ürün eklenebilir.', 422);
            }
            $newQuantity = $action === 'add' ? ($_SESSION['cart'][$id] ?? 0) + $quantity : $quantity;
            if ($newQuantity > 99) {
                api_error('Bir üründen en fazla 99 adet eklenebilir.', 422);
            }
            $_SESSION['cart'][$id] = $newQuantity;
            $message = $action === 'add' ? 'Ürün sepetinize eklendi.' : 'Ürün adedi güncellendi.';
            break;

        case 'remove':
            unset($_SESSION['cart'][$id]);
            $message = 'Ürün sepetinizden çıkarıldı.';
            break;

        case 'clear':
            $_SESSION['cart'] = [];
            $message = 'Sepetiniz temizlendi.';
            break;

        case 'favorite':
            $ids = favorites();
            $position = array_search($id, $ids, true);
            if ($position === false) {
                $ids[] = $id;
                $message = 'Ürün favorilerinize eklendi.';
            } else {
                unset($ids[$position]);
                $message = 'Ürün favorilerinizden çıkarıldı.';
            }
            $_SESSION['favorites'] = array_values($ids);
            break;

        case 'demo_order':
            $summary = cart_summary();
            if ($summary['count'] === 0) {
                api_error('Demo sipariş için önce sepetinize ürün ekleyin.', 422);
            }
            $_SESSION['demo_order'] = [
                'number' => 'DEMO-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(4))),
                'created_at' => date(DATE_ATOM),
                'count' => $summary['count'],
                'subtotal' => $summary['subtotal'],
                'shipping' => 0,
                'total' => $summary['total'],
                'items' => $summary['items'],
                'demo' => true,
            ];
            $_SESSION['cart'] = [];
            $message = 'Demo sipariş oluşturuldu. Gerçek sipariş veya ödeme yapılmadı.';
            $extra['redirect'] = 'index.php?p=order';
            break;
    }

    json_response(array_merge([
        'ok' => true,
        'cart' => cart_summary(),
        'favorites' => favorites(),
        'message' => $message,
    ], $extra));
} catch (Throwable $exception) {
    error_log('FİLE demo API: ' . $exception->getMessage());
    api_error('İşlem tamamlanamadı. Lütfen daha sonra tekrar deneyin.', 500);
}
