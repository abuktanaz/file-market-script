<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
require dirname(__DIR__) . '/app/icons.php';

function query(string $key, string $fallback = ''): string {
    return isset($_GET[$key]) && is_string($_GET[$key]) ? substr(trim($_GET[$key]), 0, 200) : $fallback;
}
function normalized(string $value): string {
    return strtolower(strtr($value, ['İ'=>'i','I'=>'i','ı'=>'i','Ş'=>'s','ş'=>'s','Ğ'=>'g','ğ'=>'g','Ü'=>'u','ü'=>'u','Ö'=>'o','ö'=>'o','Ç'=>'c','ç'=>'c']));
}
$categories = json_decode(file_get_contents(dirname(__DIR__) . '/app/categories.json'), true, 512, JSON_THROW_ON_ERROR);
$categoryNames = array_column($categories, 'name', 'slug');
$p = query('p', 'home');
$p = ['urun'=>'product','kategori'=>'category','sepet'=>'cart','sayfa'=>'info'][$p] ?? $p;
$allowed = ['home','category','product','cart','favorites','info','order'];
if (!in_array($p, $allowed, true)) { $p = 'notfound'; http_response_code(404); }
$cat = query('cat');
$q = query('q');
$sort = query('sort', 'recommended');
$all = catalog();
$cart = cart_summary();
$favoriteIds = favorites();
$currentProduct = $p === 'product' ? product((int)query('id', '0')) : null;
if ($p === 'product' && !$currentProduct) { $p = 'notfound'; http_response_code(404); }
$infoPages = [
    'hakkimizda' => ['Hakkımızda', 'Alışveriş deneyiminin bir ön izlemesi', 'Bu proje, referans olarak paylaşılan market arayüzünün tasarımını incelemek ve PHP ile çalışan bir örnek sunmak için hazırlanmış bağımsız bir demodur. FİLE’nin resmî internet sitesi değildir ve marka ile bir bağlantısı yoktur. Ürünler ve fiyatlar yalnızca arayüzü göstermek için kullanılır.'],
    'teslimat-bilgisi' => ['Teslimat Bilgisi', 'Sepetten sipariş özetine', 'Bu demoda ürünleri sepetinize ekleyebilir, miktarlarını değiştirebilir ve örnek sipariş özeti oluşturabilirsiniz. Gerçek bir sipariş veya teslimat oluşturulmaz. Teslimat ücreti demo boyunca 0 TL olarak gösterilir.'],
    'iade-degisim' => ['İade & Değişim', 'Demo işlemlerinizi kolayca yönetin', 'Sepet sayfasındaki çöp kutusu simgesinden ürünleri kaldırabilir veya Sepeti temizle seçeneğiyle baştan başlayabilirsiniz. Gerçek bir satış yapılmadığı için bu demo üzerinde iade ve değişim işlemi bulunmaz.'],
    'gizlilik-politikasi' => ['Gizlilik Politikası', 'Verileriniz hakkında', 'Bu demo ad, adres, telefon, üyelik şifresi veya ödeme bilgisi istemez. Sepetiniz ve favorileriniz, PHP oturumunda tutulur. Oturumunuzu tanımak için gerekli bir oturum çerezi kullanılır. Analiz, reklam veya üçüncü taraf takip araçları bulunmaz.'],
    'kullanim-kosullari' => ['Kullanım Koşulları', 'Bağımsız arayüz demosu', 'Bu web sitesi bir arayüz ve yazılım gösterimidir. Gösterilen fiyatlar satış teklifi oluşturmaz. Demo siparişi bir alışveriş, ödeme veya sözleşme değildir. Ürün ve marka görselleri referans tasarımın sunumu için kullanılmıştır. Ticari yayına almadan önce kendi marka ve içeriklerinizi ekleyin.'],
    'iletisim' => ['İletişim', 'Bu bir örnek mağazadır', 'Bu arayüzde canlı müşteri hizmeti sunulmaz. Sağ alttaki yardım menüsünden arama, sepet ve demo siparişi özellikleri hakkında bilgi alabilirsiniz. Gerçek bir mağaza olarak yayınlarken bu sayfaya kendi iletişim bilgilerinizi ekleyin.'],
];
$infoSlug = query('s', 'hakkimizda');
if ($p === 'info' && !isset($infoPages[$infoSlug])) { $p = 'notfound'; http_response_code(404); }
$heading = $q !== '' ? 'Arama sonuçları' : ($cat !== '' ? ($categoryNames[$cat] ?? 'Kategori bulunamadı') : 'Tüm Ürünler');
$title = match($p) {
    'product' => $currentProduct['name'], 'cart' => 'Sepetim', 'favorites' => 'Favorilerim',
    'category' => $heading, 'info' => $infoPages[$infoSlug][0], 'order' => 'Demo sipariş özeti',
    'notfound' => 'Sayfa bulunamadı', default => 'Kampanyalı Ürünler',
};
function product_card(array $item, array $favoriteIds): void {
    $favorite = in_array($item['id'], $favoriteIds, true);
    $discount = $item['old_price'] > $item['price'] ? (int)round((1-$item['price']/$item['old_price'])*100) : 0;
?>
<article class="product-card" data-product="<?= (int)$item['id'] ?>">
    <a class="product-picture" href="index.php?p=product&amp;id=<?= (int)$item['id'] ?>" aria-label="<?= e($item['name']) ?> ürününü incele">
        <img src="<?= e($item['image']) ?>" alt="<?= e($item['name']) ?>" loading="lazy" width="400" height="400">
        <?php if ($discount): ?><span class="discount-badge">%<?= $discount ?> indirim</span><?php endif ?>
    </a>
    <button type="button" class="favorite-button <?= $favorite ? 'is-favorite' : '' ?>" data-action="favorite" data-id="<?= (int)$item['id'] ?>" aria-label="<?= e($item['name']) ?> favori durumunu değiştir" aria-pressed="<?= $favorite ? 'true' : 'false' ?>"><?= icon('heart') ?></button>
    <div class="product-body">
        <a class="product-name" href="index.php?p=product&amp;id=<?= (int)$item['id'] ?>"><?= e($item['name']) ?></a>
        <div class="price-line"><strong><?= money($item['price']) ?></strong><?php if ($discount): ?><del><?= money($item['old_price']) ?></del><?php endif ?></div>
        <div class="delivery-line"><?= icon('truck') ?> Örnek teslimat seçeneği</div>
        <button type="button" class="add-button" data-action="add" data-id="<?= (int)$item['id'] ?>"><?= icon('cart') ?><span>Sepete Ekle</span></button>
    </div>
</article>
<?php } ?>
<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Market alışveriş deneyimi için hazırlanmış bağımsız PHP arayüz demosu. Ürünleri keşfedin, favorilerinizi seçin ve demo sepetini deneyin.">
    <meta name="robots" content="noindex, nofollow">
    <meta name="theme-color" content="#246c3e">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($title) ?> | FİLE Arayüz Demosu</title>
    <link rel="icon" href="assets/images/logo.png" type="image/png">
    <link rel="stylesheet" href="assets/style.css?v=1">
    <script src="assets/main.js?v=1" defer></script>
</head>
<body data-page="<?= e($p) ?>">
<a class="skip-link" href="#main">İçeriğe geç</a>
<div class="demo-strip"><?= icon('info') ?> <span>Bağımsız arayüz demosu · Resmî FİLE mağazası değildir · Gerçek sipariş ve ödeme alınmaz.</span></div>
<header class="site-header">
    <div class="header-main container">
        <button class="mobile-menu icon-button" type="button" aria-label="Kategorileri aç" aria-expanded="false" aria-controls="category-menu" id="menu-toggle"><?= icon('menu') ?></button>
        <a class="brand" href="index.php" aria-label="FİLE arayüz demosu ana sayfa"><img src="assets/images/logo.png" width="155" height="50" alt="FİLE"><span>ARAYÜZ DEMOSU</span></a>
        <div class="header-actions">
            <a class="header-action favorites-link" href="index.php?p=favorites" aria-label="Favorilerim"><?= icon('heart') ?><span>Favorilerim</span></a>
            <a class="header-action cart-link" href="index.php?p=cart" aria-label="Sepetim"><?= icon('cart') ?><span>Sepetim</span><b class="cart-count" data-cart-count><?= $cart['count'] ?></b></a>
        </div>
        <form class="search-form" action="index.php" role="search">
            <input type="hidden" name="p" value="category">
            <label class="sr-only" for="search">Ürün ara</label><?= icon('search') ?>
            <input id="search" name="q" type="search" placeholder="Aradığın ürün, en taze haliyle…" value="<?= e($q) ?>" maxlength="100" autocomplete="off">
            <button type="submit" aria-label="Ara"><?= icon('search') ?></button>
        </form>
    </div>
    <nav class="main-nav" aria-label="Ana menü"><div class="nav-inner container">
        <a href="index.php" class="<?= $p === 'home' ? 'active' : '' ?>">ANA SAYFA</a>
        <div class="categories-dropdown"><button type="button" id="categories-toggle" aria-expanded="false" aria-controls="category-menu">TÜM KATEGORİLER <?= icon('chevron') ?></button></div>
        <?php foreach (array_slice($categories, 0, 6) as $category): ?><a class="<?= $cat === $category['slug'] ? 'active' : '' ?>" href="index.php?p=category&amp;cat=<?= e($category['slug']) ?>"><?= e(mb_label($category['name'])) ?></a><?php endforeach ?>
    </div></nav>
    <div class="category-menu" id="category-menu" hidden><div class="container category-grid">
        <a class="category-tile" href="index.php?p=category"><span class="category-all"><?= icon('grid') ?></span><span>Tüm Ürünler</span></a>
        <?php foreach($categories as $category): ?><a class="category-tile" href="index.php?p=category&amp;cat=<?= e($category['slug']) ?>"><img src="<?= e($category['image']) ?>" alt="" width="52" height="52"><span><?= e($category['name']) ?></span></a><?php endforeach ?>
    </div></div>
</header>
<main id="main" class="container main-content">
<?php if ($p === 'home'): ?>
    <div class="promotion-bar"><?= icon('clock') ?><span>Haftanın kampanyaları</span><span class="promotion-pill">Örnek ürün kataloğu</span></div>
    <section class="hero" aria-label="Kampanyalar" aria-roledescription="slayt gösterisi">
        <a class="hero-slide is-active" href="index.php?p=category"><img src="assets/images/19bf5f1a7751f5eefe99.png" alt="FİLE artık online'da. Sevdiğin ürünler şimdi internetten. Referans tasarım görseli." width="1536" height="540" fetchpriority="high"></a>
        <a class="hero-slide" href="index.php?p=category&amp;cat=firsatlar" hidden><img src="assets/images/1dbda7a70be2657f14f5.png" alt="Haftanın fırsat ürünlerini keşfedin. Referans tasarım görseli." width="1536" height="540"></a>
        <div class="hero-dots" role="group" aria-label="Kampanya seç"><button class="active" type="button" data-slide="0" aria-label="Kampanya 1" aria-pressed="true"></button><button type="button" data-slide="1" aria-label="Kampanya 2" aria-pressed="false"></button></div>
    </section>
    <section class="catalog-section" aria-labelledby="campaign-heading">
        <div class="section-heading"><div><h1 id="campaign-heading">KAMPANYALI ÜRÜNLER</h1><p>Haftanın seçilenleri</p></div><a href="index.php?p=category">Tüm Ürünler <?= icon('arrow') ?></a></div>
        <div class="products-grid"><?php foreach($all as $item) product_card($item, $favoriteIds); ?></div>
        <div class="catalog-end"><span><?= count($all) ?> ürünün tamamını görüntülediniz.</span><button type="button" class="text-button" data-scroll-top>Başa dön <?= icon('up') ?></button></div>
    </section>
<?php elseif ($p === 'category' || $p === 'favorites'):
    $items = $all;
    if ($p === 'favorites') { $heading = 'Favorilerim'; $items = array_values(array_filter($items, fn($v)=>in_array($v['id'],$favoriteIds,true))); }
    elseif ($cat === 'firsatlar') $items = array_values(array_filter($items, fn($v)=>$v['old_price']>$v['price']));
    elseif ($cat === 'yeni-urunler') $items = array_slice(array_reverse($items),0,12);
    elseif ($cat !== '') $items = array_values(array_filter($items, fn($v)=>$v['category']===$cat));
    if ($q !== '') $items = array_values(array_filter($items, fn($v)=>str_contains(normalized($v['name'].' '.$v['description']),normalized($q))));
    if ($sort==='price-asc') usort($items,fn($a,$b)=>$a['price']<=>$b['price']);
    elseif ($sort==='price-desc') usort($items,fn($a,$b)=>$b['price']<=>$a['price']);
    elseif ($sort==='name') usort($items,fn($a,$b)=>strcmp(normalized($a['name']),normalized($b['name'])));
?>
    <div class="breadcrumb"><a href="index.php">Ana Sayfa</a><span>›</span><span><?= e($heading) ?></span></div>
    <div class="listing-heading"><div><span class="eyebrow"><?= $p==='favorites' ? 'SİZİN SEÇTİKLERİNİZ' : 'ÜRÜNLERİ KEŞFEDİN' ?></span><h1><?= e($heading) ?></h1><p><?= $q !== '' ? '“'.e($q).'” için ' : '' ?><?= count($items) ?> ürün listeleniyor</p></div>
        <form action="index.php" class="sort-form"><input type="hidden" name="p" value="<?= e($p) ?>"><input type="hidden" name="cat" value="<?= e($cat) ?>"><input type="hidden" name="q" value="<?= e($q) ?>"><label for="sort">Sıralama</label><select name="sort" id="sort"><option value="recommended" <?= $sort==='recommended'?'selected':'' ?>>Önerilen</option><option value="price-asc" <?= $sort==='price-asc'?'selected':'' ?>>Fiyat: Düşükten yükseğe</option><option value="price-desc" <?= $sort==='price-desc'?'selected':'' ?>>Fiyat: Yüksekten düşüğe</option><option value="name" <?= $sort==='name'?'selected':'' ?>>Ürün adı: A–Z</option></select><button class="sort-submit" type="submit" aria-label="Sıralamayı uygula"><?= icon('arrow') ?></button></form>
    </div>
    <?php if ($p !== 'favorites'): ?><div class="category-chips"><a class="<?= $cat===''?'selected':'' ?>" href="index.php?p=category">Tümü</a><?php foreach($categories as $category): ?><a class="<?= $cat===$category['slug']?'selected':'' ?>" href="index.php?p=category&amp;cat=<?= e($category['slug']) ?>"><?= e($category['name']) ?></a><?php endforeach ?></div><?php endif ?>
    <?php if ($items): ?><div class="products-grid"><?php foreach($items as $item) product_card($item,$favoriteIds); ?></div><?php else: ?><div class="empty-state"><?= icon($p==='favorites'?'heart':'search') ?><h2><?= $p==='favorites'?'Favori listeniz sizi bekliyor':'Henüz bir ürün bulunamadı' ?></h2><p><?= $p==='favorites'?'Ürünlerdeki kalp simgesine dokunarak beğendiklerinizi burada biriktirin.':'Farklı bir ürün adı arayın veya diğer kategorileri keşfedin.' ?></p><a class="primary-button" href="index.php?p=category">Ürünleri keşfet <?= icon('arrow') ?></a></div><?php endif ?>
<?php elseif ($p === 'product'): $item = $currentProduct; ?>
    <div class="breadcrumb"><a href="index.php">Ana Sayfa</a><span>›</span><a href="index.php?p=category&amp;cat=<?= e($item['category']) ?>"><?= e($categoryNames[$item['category']]??'Ürünler') ?></a><span>›</span><span><?= e($item['name']) ?></span></div>
    <section class="product-detail"><div class="detail-image"><img src="<?= e($item['image']) ?>" alt="<?= e($item['name']) ?>" width="700" height="700"></div><div class="detail-copy"><span class="eyebrow"><?= e($categoryNames[$item['category']]??'ÜRÜN') ?></span><h1><?= e($item['name']) ?></h1><div class="price-line detail-price"><strong><?= money($item['price']) ?></strong><?php if($item['old_price']>$item['price']): ?><del><?= money($item['old_price']) ?></del><?php endif ?></div><span class="demo-price-label">Demo kataloğundaki örnek fiyat</span><p class="description"><?= nl2br(e($item['description'])) ?></p>
        <div class="purchase-row"><div class="quantity-picker"><button type="button" data-detail-quantity="-1" aria-label="Adedi azalt"><?= icon('minus') ?></button><label class="sr-only" for="detail-quantity">Adet</label><input type="number" id="detail-quantity" value="1" min="1" max="99" inputmode="numeric"><button type="button" data-detail-quantity="1" aria-label="Adedi artır"><?= icon('plus') ?></button></div><button type="button" class="primary-button" data-action="add" data-id="<?= (int)$item['id'] ?>" data-detail-add><?= icon('cart') ?> Sepete Ekle</button><button type="button" class="detail-favorite icon-button <?= in_array($item['id'],$favoriteIds,true)?'is-favorite':'' ?>" data-action="favorite" data-id="<?= (int)$item['id'] ?>" aria-label="Favori durumunu değiştir" aria-pressed="<?= in_array($item['id'],$favoriteIds,true)?'true':'false' ?>"><?= icon('heart') ?></button></div>
        <div class="detail-benefits"><span><?= icon('leaf') ?> Geniş ürün seçeneği</span><span><?= icon('shield') ?> Bilgi girmeden demo deneyimi</span></div><details class="product-accordion" open><summary>Ürün bilgisi</summary><dl><div><dt>Kategori</dt><dd><?= e($categoryNames[$item['category']]??'Ürünler') ?></dd></div><div><dt>Ürün kodu</dt><dd>#<?= (int)$item['id'] ?></dd></div><div><dt>Satış durumu</dt><dd>Yalnızca gösterim</dd></div></dl></details></div></section>
    <section class="related-section"><div class="section-heading"><div><h2>BUNLARI DA KEŞFEDİN</h2><p>Alışveriş listenize ilham olsun</p></div></div><div class="products-grid"><?php $related=array_slice(array_values(array_filter($all,fn($v)=>$v['id']!==$item['id']&&$v['category']===$item['category'])),0,4); foreach($related as $relatedItem) product_card($relatedItem,$favoriteIds); ?></div></section>
<?php elseif ($p === 'cart'): ?>
    <div class="breadcrumb"><a href="index.php">Ana Sayfa</a><span>›</span><span>Sepetim</span></div><div class="listing-heading"><div><span class="eyebrow">ALIŞVERİŞ LİSTENİZ</span><h1>Sepetim <span class="heading-count" data-cart-count><?= $cart['count'] ?></span></h1><p>Seçtikleriniz, tek bir yerde.</p></div><?php if($cart['count']): ?><button type="button" class="text-button" data-action="clear"><?= icon('trash') ?> Sepeti temizle</button><?php endif ?></div>
    <div id="cart-content">
    <?php if (!$cart['count']): ?><div class="empty-state"><?= icon('bag') ?><h2>Sepetiniz henüz boş</h2><p>Haftanın seçilen ürünlerini keşfedin, alışveriş listenizi oluşturmaya başlayın.</p><a class="primary-button" href="index.php">Alışverişe başla <?= icon('arrow') ?></a></div>
    <?php else: ?><div class="cart-layout"><div class="cart-items"><?php foreach($cart['items'] as $row): $item=$row['product']; ?><article class="cart-item" data-cart-row="<?= (int)$item['id'] ?>"><a href="index.php?p=product&amp;id=<?= (int)$item['id'] ?>"><img src="<?= e($item['image']) ?>" alt="<?= e($item['name']) ?>" width="100" height="100"></a><div class="cart-item-info"><a href="index.php?p=product&amp;id=<?= (int)$item['id'] ?>"><?= e($item['name']) ?></a><span><?= money($item['price']) ?> / adet</span><div class="quantity-picker"><button type="button" data-action="quantity" data-id="<?= (int)$item['id'] ?>" data-delta="-1" aria-label="<?= e($item['name']) ?> adedini azalt"><?= icon('minus') ?></button><output data-row-quantity><?= (int)$row['quantity'] ?></output><button type="button" data-action="quantity" data-id="<?= (int)$item['id'] ?>" data-delta="1" aria-label="<?= e($item['name']) ?> adedini artır"><?= icon('plus') ?></button></div></div><strong data-line-total><?= money($row['line_total']) ?></strong><button type="button" class="remove-button icon-button" data-action="remove" data-id="<?= (int)$item['id'] ?>" aria-label="<?= e($item['name']) ?> sepetten kaldır"><?= icon('trash') ?></button></article><?php endforeach ?><a class="continue-shopping" href="index.php?p=category"><?= icon('arrow') ?> Alışverişe devam et</a></div><aside class="order-summary"><h2>Sepet özeti</h2><div><span>Ara toplam</span><span data-subtotal><?= money($cart['subtotal']) ?></span></div><div><span>Demo teslimat</span><span class="green">Ücretsiz</span></div><div class="summary-total"><strong>Toplam</strong><strong data-total><?= money($cart['total']) ?></strong></div><p class="summary-notice"><?= icon('info') ?> Ödeme ve kişisel bilgi istemeyen bir demo siparişi oluşturabilirsiniz.</p><button type="button" class="primary-button" data-action="demo_order">Demo siparişi oluştur <?= icon('arrow') ?></button><span class="summary-footnote">Gerçek sipariş, tahsilat veya teslimat yapılmaz.</span></aside></div><?php endif ?>
    </div>
<?php elseif ($p === 'order'): $order = $_SESSION['demo_order'] ?? null; ?>
    <?php if($order): ?><section class="order-success"><div class="success-icon"><?= icon('check') ?></div><span class="eyebrow">DEMO TAMAMLANDI</span><h1>Alışveriş deneyiminiz hazır.</h1><p>Örnek sipariş özetiniz oluşturuldu. Gerçek sipariş veya ödeme alınmadı.</p><div class="order-receipt"><div><span>Demo numarası</span><strong><?= e($order['number']) ?></strong></div><?php foreach($order['items'] as $row): ?><div><span><?= (int)$row['quantity'] ?> × <?= e($row['product']['name']) ?></span><strong><?= money($row['line_total']) ?></strong></div><?php endforeach ?><div class="receipt-total"><span>Örnek toplam</span><strong><?= money($order['total']) ?></strong></div></div><a class="primary-button" href="index.php">Ürünlere dön <?= icon('arrow') ?></a></section><?php else: ?><div class="empty-state"><?= icon('bag') ?><h1>Henüz demo siparişi yok</h1><p>Sepetinize ürün ekleyerek alışveriş deneyimini deneyin.</p><a class="primary-button" href="index.php">Ürünlere dön</a></div><?php endif ?>
<?php elseif ($p === 'info'): $info=$infoPages[$infoSlug]; ?>
    <div class="breadcrumb"><a href="index.php">Ana Sayfa</a><span>›</span><span><?= e($info[0]) ?></span></div><article class="info-page"><span class="eyebrow">BİLGİ MERKEZİ</span><h1><?= e($info[0]) ?></h1><h2><?= e($info[1]) ?></h2><p><?= e($info[2]) ?></p><div class="info-callout"><?= icon('info') ?><p>Bağımsız PHP arayüz demosu. Resmî FİLE mağazası değildir.</p></div><a class="text-link" href="index.php">Ana sayfaya dön <?= icon('arrow') ?></a></article>
<?php else: ?><div class="empty-state"><?= icon('search') ?><span class="eyebrow">404</span><h1>Bu sayfayı bulamadık.</h1><p>Aradığınız ürün veya sayfa mevcut olmayabilir.</p><a class="primary-button" href="index.php">Ana sayfaya dön <?= icon('arrow') ?></a></div><?php endif ?>
</main>
<section class="service-strip"><div class="container"><div><?= icon('leaf') ?><span><strong>Her ihtiyaca bir seçenek</strong><small>Geniş ürün kataloğu</small></span></div><div><?= icon('truck') ?><span><strong>Kolay alışveriş deneyimi</strong><small>Arayın, keşfedin, sepetinize ekleyin</small></span></div><div><?= icon('shield') ?><span><strong>Şeffaf demo deneyimi</strong><small>Üyelik ve ödeme bilgisi gerekmez</small></span></div></div></section>
<footer class="site-footer"><div class="container footer-main"><div class="footer-brand"><a href="index.php"><img src="assets/images/logo.png" alt="FİLE" width="130" height="45"></a><span class="eyebrow">BAĞIMSIZ ARAYÜZ DEMOSU</span><p>Günlük ihtiyaçlardan haftanın seçilenlerine, market alışverişi deneyiminin PHP ile hazırlanmış bir örneği.</p></div><div><h3>KURUMSAL</h3><a href="index.php?p=info&amp;s=hakkimizda">Hakkımızda</a><a href="index.php?p=info&amp;s=iletisim">İletişim</a><a href="index.php?p=category">Ürün Kataloğu</a><a href="index.php?p=favorites">Favorilerim</a></div><div><h3>YARDIM</h3><a href="index.php?p=info&amp;s=teslimat-bilgisi">Teslimat Bilgisi</a><a href="index.php?p=info&amp;s=iade-degisim">İade & Değişim</a><a href="index.php?p=info&amp;s=gizlilik-politikasi">Gizlilik Politikası</a><a href="index.php?p=info&amp;s=kullanim-kosullari">Kullanım Koşulları</a></div><div class="footer-about"><h3>DEMO HAKKINDA</h3><p><?= icon('info') ?> Gerçek bir satış mağazası değildir.</p><p><?= icon('shield') ?> Kişisel bilgi ve ödeme alınmaz.</p><a href="index.php?p=info&amp;s=hakkimizda" class="footer-more">Daha fazla bilgi <?= icon('arrow') ?></a></div></div><div class="container footer-bottom"><span>© <?= date('Y') ?> · PHP Market Arayüz Demosu</span><span>FİLE ile resmî bir bağlantısı bulunmamaktadır.</span></div></footer>
<div class="floating-tools"><button class="scroll-top icon-button" type="button" data-scroll-top aria-label="Yukarı çık"><?= icon('up') ?></button><button class="support-button" type="button" id="support-toggle" aria-label="Demo yardımını aç" aria-expanded="false" aria-controls="support-panel"><?= icon('support') ?></button></div>
<section class="support-panel" id="support-panel" aria-label="Demo yardımı" hidden><div class="support-header"><div><?= icon('support') ?><span><strong>Size nasıl yardımcı olalım?</strong><small>Demo kullanım rehberi</small></span></div><button class="icon-button" id="support-close" type="button" aria-label="Yardımı kapat"><?= icon('close') ?></button></div><div class="support-body"><p>Merhaba! Bu arayüzün özelliklerini aşağıdan keşfedebilirsiniz.</p><details><summary>Ürünleri nasıl bulabilirim?</summary><p>Üstteki arama kutusuna ürün adını yazın veya Tüm Kategoriler menüsünü kullanın. Sonuçları fiyata göre sıralayabilirsiniz.</p></details><details><summary>Sepetimi nasıl düzenlerim?</summary><p>Sepete Ekle düğmesini kullanın. Sepetim sayfasında + ve − düğmeleriyle adetleri değiştirin, çöp kutusuyla ürünü kaldırın.</p></details><details><summary>Gerçek sipariş veriliyor mu?</summary><p>Hayır. Bu bir arayüz demosudur. Ödeme ve kişisel bilgi alınmaz. Demo siparişinde yalnızca seçtiğiniz ürünlerin özeti gösterilir.</p></details><a class="text-link" href="index.php?p=info&amp;s=gizlilik-politikasi">Gizlilik hakkında <?= icon('arrow') ?></a></div></section>
<nav class="mobile-bottom-nav" aria-label="Mobil gezinme"><a href="index.php" class="<?= $p==='home'?'active':'' ?>"><?= icon('bag') ?><span>Ana Sayfa</span></a><a href="index.php?p=category" class="<?= $p==='category'?'active':'' ?>"><?= icon('grid') ?><span>Kategoriler</span></a><a href="index.php?p=favorites" class="<?= $p==='favorites'?'active':'' ?>"><?= icon('heart') ?><span>Favoriler</span></a><a href="index.php?p=cart" class="<?= $p==='cart'?'active':'' ?>"><?= icon('cart') ?><span>Sepetim <b data-cart-count><?= $cart['count'] ?></b></span></a></nav>
<div class="toast" id="toast" role="status" aria-live="polite" hidden></div>
</body>
</html>
<?php
function mb_label(string $value): string {
    return strtoupper(strtr($value, ['i'=>'İ','ı'=>'I','ş'=>'Ş','ğ'=>'Ğ','ü'=>'Ü','ö'=>'Ö','ç'=>'Ç']));
}
