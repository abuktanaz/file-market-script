param(
    [ValidateRange(1024, 65535)]
    [int]$Port = 8080
)

$ErrorActionPreference = 'Stop'
$projectDirectory = $PSScriptRoot
$publicDirectory = Join-Path $projectDirectory 'public'
$bundledPhp = Join-Path (Split-Path -Parent $projectDirectory) '.tools\php\php.exe'

if (Test-Path -LiteralPath $bundledPhp -PathType Leaf) {
    $phpExecutable = $bundledPhp
} else {
    $phpCommand = Get-Command 'php' -ErrorAction SilentlyContinue
    if ($null -eq $phpCommand) {
        throw 'PHP bulunamadı. PHP 8.2 veya üzerini kurup PATH değişkenine ekleyin.'
    }
    $phpExecutable = $phpCommand.Source
}

& $phpExecutable -r 'exit(PHP_VERSION_ID >= 80200 ? 0 : 1);'
if ($LASTEXITCODE -ne 0) {
    throw 'Bu proje PHP 8.2 veya üzerini gerektirir.'
}

Write-Host "FİLE bağımsız demo: http://127.0.0.1:$Port"
Write-Host 'Sunucuyu durdurmak için Ctrl+C kullanın.'
& $phpExecutable -S "127.0.0.1:$Port" -t $publicDirectory
exit $LASTEXITCODE
